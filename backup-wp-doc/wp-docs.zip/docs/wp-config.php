<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'dbqdfxsyyv3xgr' );

/** Database username */
define( 'DB_USER', 'ujalzu4fp74gn' );

/** Database password */
define( 'DB_PASSWORD', 'lxagcucebwav' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          ')2(u3ir`cINDy{WdaihZJ@JU}x[kq4Vt62iw2S-GaDJa>+ FVv+QaRI3x|iW2-I;' );
define( 'SECURE_AUTH_KEY',   'OuxjLhoDat-I8Q3AVw[BmKGvYb,9.`[%A~m6E%|:w^QF309;3<-Cybhu4Hk [V]y' );
define( 'LOGGED_IN_KEY',     '><>~&|6E,J9]D(%o~sSxD]Z[,[=7lzk|`ma1}$qJ`j1Qvx`RKrn8 4vpWyx#Z/FZ' );
define( 'NONCE_KEY',         'mGHK5c1&;v54v$0Rh>^QQ][0,%[mDHLgdR5*J<}@-WSQ!0B[YABw``4^X[6lr/ ~' );
define( 'AUTH_SALT',         'R9a@nXd#>1FIMsjWo/{/7HNossSEf+uUZ^^/Hy1*D`_Hm&m04K!?04C.vP)y,-!y' );
define( 'SECURE_AUTH_SALT',  've](9cR1KvB``M~jVn%uPhGCJQ Q%At/zqeL d`vr~8nWnk+rxYT`+WWm]Y6R}.X' );
define( 'LOGGED_IN_SALT',    'MP]k:~l4@^s?T;pzLic_^AV)dMHM[~wo]Z ]#``1vOl,LBSCV(UZ#7.Itb[Ddj$ ' );
define( 'NONCE_SALT',        'W0R;{(v@Q*m*G-d!3kAT,N>~}|:&mpEH:lt 2OMW>4cYn6Xd$nBF.d-8,C-{1<@b' );
define( 'WP_CACHE_KEY_SALT', '[4v_5A1Z1)Lsb;6Y45*MgF2egKp.&2S$~5HAbkWiHHm._iCX86K;NR$kDFY~$o3 ' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wzn_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
@include_once('/var/lib/sec/wp-settings-pre.php'); // Added by SiteGround WordPress management system
require_once ABSPATH . 'wp-settings.php';
@include_once('/var/lib/sec/wp-settings.php'); // Added by SiteGround WordPress management system
